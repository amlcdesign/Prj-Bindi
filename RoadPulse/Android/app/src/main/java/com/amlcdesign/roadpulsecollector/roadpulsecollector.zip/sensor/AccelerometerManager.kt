package com.amlcdesign.roadpulsecollector.sensor

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import com.amlcdesign.roadpulsecollector.enums.SensorSamplingProfile
import com.amlcdesign.roadpulsecollector.model.AccelerometerRecord
import java.time.OffsetDateTime
import java.time.format.DateTimeFormatter
import com.amlcdesign.roadpulsecollector.utils.RoadPulseLogger

class AccelerometerManager(
    context: Context,
    private val onSample: (AccelerometerRecord) -> Unit
) : SensorEventListener {

    private val sensorManager =
        context.getSystemService(
            Context.SENSOR_SERVICE
        ) as SensorManager

    private val accelerometer =
        sensorManager.getDefaultSensor(
            Sensor.TYPE_ACCELEROMETER
        )

    private var samplingIntervalMs =
        SensorSamplingProfile.LOW_SPEED.intervalMs

    private var lastSampleTimestamp = 0L
    private var isRunning = false

    fun updateSpeed(speedKmh: Float) {

        val profile =
            SensorSamplingProfile.forSpeed(speedKmh)

        samplingIntervalMs =
            profile.intervalMs

        RoadPulseLogger.accel(
            "Speed = ${"%.1f".format(speedKmh)} km/h" +
                    " | Profile = $profile" +
                    " | Interval = ${samplingIntervalMs} ms"
        )
    }

    fun start() {

        if (isRunning) {
            return
        }
        isRunning = true

        lastSampleTimestamp = 0L

        RoadPulseLogger.accel(
            "Accelerometer starting"
        )

        accelerometer?.let { sensor ->

            sensorManager.registerListener(
                this,
                sensor,
                SensorManager.SENSOR_DELAY_NORMAL
            )
            RoadPulseLogger.accel(
                "Accelerometer registered"
            )
        } ?: run {
            RoadPulseLogger.error(
                "Accelerometer sensor not available"
            )
        }
    }

    fun stop() {

        if (!isRunning) {
            return
        }
        isRunning = false

        sensorManager.unregisterListener(this)
        lastSampleTimestamp = 0L
        RoadPulseLogger.accel(
            "Accelerometer stopped"
        )
    }

    override fun onSensorChanged(
        event: SensorEvent
    ) {
        if (!isRunning) {
            return
        }

        if (event.sensor.type != Sensor.TYPE_ACCELEROMETER) {
            return
        }

        val now =
            System.currentTimeMillis()

        if (
            lastSampleTimestamp != 0L &&
            now - lastSampleTimestamp < samplingIntervalMs
        ) {
            return
        }

        lastSampleTimestamp = now

        val timestampIso =
            OffsetDateTime.now()
                .format(
                    DateTimeFormatter.ISO_OFFSET_DATE_TIME
                )

        onSample(
            AccelerometerRecord(

                timestampEpoch = now,

                timestampIso = timestampIso,

                x = event.values[0],

                y = event.values[1],

                z = event.values[2],

                samplingIntervalMs =
                    samplingIntervalMs
            )
        )
    }

    override fun onAccuracyChanged(
        sensor: Sensor?,
        accuracy: Int
    ) {
        // Not required for current data collection.
    }
}